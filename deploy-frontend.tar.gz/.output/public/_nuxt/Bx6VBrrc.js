import{f as e,n as a,c as o,o as n}from"./CpVhbLmw.js";const _={__name:"index",setup(t){return e(()=>{a("/dashboard")}),(r,s)=>(n(),o("div"))}};export{_ as default};
