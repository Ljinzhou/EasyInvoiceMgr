import"./CpVhbLmw.js";const s=globalThis.setInterval;export{s};
