function s(){function r(t){return t?t.startsWith("http://")||t.startsWith("https://")||t.startsWith("/")?t:"/"+t:""}return{getUploadUrl:r}}export{s as u};
